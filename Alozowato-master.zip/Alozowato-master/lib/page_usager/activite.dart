
class Activite {
  int id;
  String nom;
  double hue;

  Activite({this.nom, this.id, this.hue});
}
