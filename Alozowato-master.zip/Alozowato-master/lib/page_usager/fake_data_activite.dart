

import 'package:alonouz_mobile/page_usager/activite.dart';

List<Activite> listactivites = [
    Activite(id: 0,nom: 'Tous'),
    Activite(id: 1,nom: 'Menusiers'),
    Activite(id: 2,nom: 'Couturier'),
    Activite(id: 3,nom: 'Coiffeur'),
    Activite(id: 4,nom: 'Vitrié'),
    Activite(id: 5,nom: 'Coiffeuse'),
  ];